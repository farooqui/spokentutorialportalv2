Refer to http://drupal.org/node/303203 for configuration details.

$Id: README.txt,v 1.3 2008/12/08 00:14:18 stuartgreenfield Exp $