<?php print drupal_render($form) ?>
<div class='buttons'><?php print drupal_render($buttons) ?></div>
