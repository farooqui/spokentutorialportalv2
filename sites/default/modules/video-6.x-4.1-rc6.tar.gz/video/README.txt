// $Id: README.txt,v 1.8.4.5.4.5.2.4 2010/07/10 04:02:19 heshanmw Exp $
------------

 to embed videos into drupal pages, using CCK and filefield support.
This module add the possibility to create video nodes which are containers
 to embed videos into drupal pages, using CCK and filefield support.

For information about supported file types see FILE_TYPES.txt
http://video.heidisoft.com/content/welcome-video-module-documentation

For general instructions read video.module handbook:
http://video.heidisoft.com/content/features

Please submit bugs/features/support requests at:
  http://video.heidisoft.com/content/welcome-video-module-documentation
  http://video.heidisoft.com/contact


Maintainers
-----------

	Heshan Wanigasooriya :heshan at heidisoft dot com, heshanmw at gmail dot com
  Dennis : http://drupal.org/user/384543
  Glen Marianko : http://drupal.org/usr/527446 http://linkedin.com/in/glenergetic twitter: @glenergetic