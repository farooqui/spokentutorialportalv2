<?php 
//$Id: video-play-flv.tpl.php,v 1.1.2.4 2010/05/10 18:24:53 iLLin Exp $
/*
 * @file
 * Theme file to handle flv output.
 * 
 * Variables passed.
 * $video is the video object.
 * $node is the node object.
 * $themed_output is the rendered html.
 * 
 */
print $themed_output;
?>